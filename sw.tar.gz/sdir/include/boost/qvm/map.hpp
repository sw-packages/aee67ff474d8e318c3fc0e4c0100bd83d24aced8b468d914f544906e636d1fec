//Copyright (c) 2008-2016 Emil Dotchevski and Reverge Studios, Inc.

//Distributed under the Boost Software License, Version 1.0. (See accompanying
//file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef UUID_74318C76B4ED11E58A3AE198BB8E7F8B
#define UUID_74318C76B4ED11E58A3AE198BB8E7F8B

#include <boost/qvm/map_vec_mat.hpp>
#include <boost/qvm/map_mat_vec.hpp>
#include <boost/qvm/map_mat_mat.hpp>

#endif
